# View DEMO - http://nginxmicroservice.ml/

1. Dond forget make copy of bootstrap.scss with name bootstrap2.scss and put them near original bootstrap.scss