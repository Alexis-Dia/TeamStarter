import HomeView from './components/MainView'

// Sync route definition
export default {
  component : HomeView
}
